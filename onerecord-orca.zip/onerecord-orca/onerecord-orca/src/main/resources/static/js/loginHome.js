
$(document).ready(function() {
    console.log('Inside the one loginHome.js');
    if(window.document.querySelector(`div[data-name="awbFullData"]`)){
		window.document.querySelector(`div[data-name="awbFullData"]`).style.display = "none";
	}
	
	
});

function hideAllGrids() {
	if(window.document.querySelector(`div[data-name="awbInfoGrid1"]`)){
		window.document.querySelector(`div[data-name="awbInfoGrid1"]`).style.display = "none";
	}
	if(window.document.querySelector(`div[data-name="awbInfoGrid2"]`)){
		window.document.querySelector(`div[data-name="awbInfoGrid2"]`).style.display = "none";
	}
	if(window.document.querySelector(`div[data-name="awbInfoGrid3"]`)){
		window.document.querySelector(`div[data-name="awbInfoGrid3"]`).style.display = "none";
	}
	if(window.document.querySelector(`div[data-name="awbInfoGrid4"]`)){
		window.document.querySelector(`div[data-name="awbInfoGrid4"]`).style.display = "none";
	}
	
	if(window.document.querySelector(`div[data-name="awbFullData"]`)){
		window.document.querySelector(`div[data-name="awbFullData"]`).style.display = "none";
	}
} 

function showAllGrids() {
	if(window.document.querySelector(`div[data-name="awbInfoGrid1"]`)){
		window.document.querySelector(`div[data-name="awbInfoGrid1"]`).style.display = "block";
	}
	if(window.document.querySelector(`div[data-name="awbInfoGrid2"]`)){
		window.document.querySelector(`div[data-name="awbInfoGrid2"]`).style.display = "block";
	}
	if(window.document.querySelector(`div[data-name="awbInfoGrid3"]`)){
		window.document.querySelector(`div[data-name="awbInfoGrid3"]`).style.display = "block";
	}
	if(window.document.querySelector(`div[data-name="awbInfoGrid4"]`)){
		window.document.querySelector(`div[data-name="awbInfoGrid4"]`).style.display = "block";
	}
	
	if(window.document.querySelector(`div[data-name="awbFullData"]`)){
		window.document.querySelector(`div[data-name="awbFullData"]`).style.display = "block";
	}
} 

inputAwbObj = {awbPrfx: "", awbNumber: "", published:false}
awbResponseObj = {awbPrfx: "", awbNumber: ""}
function myfunction() {
     console.log("InputUserObj : ");

}

function myfunction() {
    console.log("welcome to Javatpoint   :  " + this.document.querySelector('input[data-name="serAwbPrfx"]').value);
    if(window.event.target.dataset.name === 'serAwbPrfx'){
        this.inputAwbObj.awbPrfx=this.document.querySelector('input[data-name="serAwbPrfx"]').value;
    }
    if(window.event.target.dataset.name === 'serAwbNumber'){
        this.inputAwbObj.awbNumber=this.document.querySelector('input[data-name="serAwbNumber"]').value;
    }
    console.log("InputUserObj : " + JSON.stringify(this.inputAwbObj));
}

function getAwbInfo(loginPlace) {
	if(window.document.querySelector(`div[data-name="awbFullData"]`)){
		window.document.querySelector(`div[data-name="awbFullData"]`).style.display = "block";
	}
	//if(window.document.querySelector(`div[data-name="showOciCaptureGrid"]`)){
		//window.document.querySelector(`div[data-name="showOciCaptureGrid"]`).style.display = "none";
	//}
	this.inputAwbObj.loginPlace=loginPlace
    $.ajax({type: "POST",
        url: "/fetchAwbInfo",
        data:JSON.stringify(this.inputAwbObj),
        contentType : 'application/json; charset=utf-8',
        dataType : 'json',
        success: function (response) {
			this.awbResponseObj=JSON.parse(JSON.stringify(response));
            console.log("InputUserObj : " + response);
            updaetAwbInfo(response);
        }
    });
}

function updaetAwbInfo(response) {
	if(window.document.querySelector(`button[data-name="captureOciBtn"]`)){
		window.document.querySelector(`button[data-name="captureOciBtn"]`).disabled = true;
	}
   let awbDtlIds=['awbType', 'awbPrfx', 'awbNumber', 'pcs', 'weight', 'volume', 'orig', 'dest', 'product', 'shc'];
   let fltDtlIds=['carrier', 'carNum', 'fromApt', 'toApt', 'deptDt', 'arrDt'];
   awbDtlIds.forEach(element => {
		if(this.document.querySelector(`td[data-name="${element}"]`) != undefined){
			this.document.querySelector(`td[data-name="${element}"]`).innerText=response[element];
		}

	})
	response.flights.forEach(flt => {
		fltDtlIds.forEach(fltelement => {
			if(this.document.querySelector(`td[data-name="${fltelement}${flt.seqNum}"]`) != undefined){
				this.document.querySelector(`td[data-name="${fltelement}${flt.seqNum}"]`).innerText=flt[fltelement];
			}
			
		})
	});
	if(response.screeningDom != undefined && response.screeningDom != ''){
		this.document.querySelector(`div[data-name="screeningdiv"]`).innerHTML=	response.screeningDom;
	}
	if(response.mandateComplted && window.document.querySelector(`button[data-name="captureOciBtn"]`)){
		window.document.querySelector(`button[data-name="captureOciBtn"]`).disabled = false;
	}
	//if(response.mandateComplted && window.document.querySelector(`div[data-name="showOciCaptureGrid"]`)){
		//window.document.querySelector(`div[data-name="showOciCaptureGrid"]`).style.display = "block";
	//}
	//data-name="captureOciBtn"
   
}


function updateStatus(screenigUniqueId){
	this.inputAwbObj.screenigUniqueId=screenigUniqueId;
	  $.ajax({type: "POST",
        url: "/updateStatus",
        data:JSON.stringify(this.inputAwbObj),
        contentType : 'application/json; charset=utf-8',
        dataType : 'json',
        success: function (response) {
			this.awbResponseObj=JSON.parse(JSON.stringify(response));
            console.log("InputUserObj : " + response);
            updaetAwbInfo(response);
        }
    });
}

function captureOci(place){
	let awbPrfx = this.inputAwbObj.awbPrfx;
	let awbNumber = this.inputAwbObj.awbNumber;
	window.location.href = `http://localhost:9090/ociStamping.html?awbPrfx=${awbPrfx}&awbNumber=${awbNumber}&loginPlace=${place}`;
}

function publishData(){
	let urlParams = new URLSearchParams(window.location.search);
	this.inputAwbObj.awbPrfx=urlParams.get('awbPrfx');
	this.inputAwbObj.awbNumber=urlParams.get('awbNumber');
	this.inputAwbObj.loginPlace=urlParams.get('loginPlace');
	let loginPlace=urlParams.get('loginPlace');
	  $.ajax({type: "POST",
        url: "/publishToOneRecord",
        data:JSON.stringify(this.inputAwbObj),
        contentType : 'application/json; charset=utf-8',
        dataType : 'json',
        success: function (response) {
			this.awbResponseObj=JSON.parse(JSON.stringify(response));
            console.log("InputUserObj : " + response);
            //if(response.oneRecordUpdated===true){
				//this.document.querySelector(`div[data-name="publishDiv"]`).innerHTML='<div></div>';
			//}
			navigateToHome(loginPlace);
        }
    });
}
function navigateToHome(loginPlace) {

	if(loginPlace === 'DOH'){
		window.location.href = "http://localhost:9090/dohaHome.html";
	} else if(loginPlace === 'DAC'){
		window.location.href = "http://localhost:9090/dhakaHome.html";
	} else if(loginPlace === 'FRA'){
		window.location.href = "http://localhost:9090/fraHome.html";
	}  else {
		window.location.href = "http://localhost:9090/errorPage.html";
	}
}	
