package com.onerecordorca.login.schemaobjects;

import java.io.Serializable;

public class SearchShipmentSO implements Serializable {
	
	private static final long serialVersionUID = 1l;
	
	private String oneRecordId;
	private String docPrefix;
	private String docNumber;
	public String getDocPrefix() {
		return docPrefix;
	}
	public void setDocPrefix(String docPrefix) {
		this.docPrefix = docPrefix;
	}
	public String getDocNumber() {
		return docNumber;
	}
	public void setDocNumber(String docNumber) {
		this.docNumber = docNumber;
	}
	public String getOneRecordId() {
		return oneRecordId;
	}
	public void setOneRecordId(String oneRecordId) {
		this.oneRecordId = oneRecordId;
	}
	
}
