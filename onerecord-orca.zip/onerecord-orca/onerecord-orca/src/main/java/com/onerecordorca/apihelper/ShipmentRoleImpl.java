package com.onerecordorca.apihelper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.onerecordorca.login.schemaobjects.LogisticsObjectSO;
import com.onerecordorca.login.schemaobjects.SearchShipmentSO;

@Component
public class ShipmentRoleImpl {

	@Autowired
	private APIServiceInvoker serviceInvoker;
	
	public String saveShipment(String message) {
		return serviceInvoker.saveShipment(message);
	}

	public LogisticsObjectSO getShipment(SearchShipmentSO searchShipmentSO) {
		return serviceInvoker.getShipment(searchShipmentSO);
	}

}
