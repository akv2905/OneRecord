package com.onerecordorca.apihelper;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.onerecordorca.login.schemaobjects.LogisticsObjectSO;
import com.onerecordorca.login.schemaobjects.SearchShipmentSO;
import com.onerecordorca.login.schemaobjects.TokenSO;

@Component
public class APIServiceInvoker {

	public String saveShipment(String message) {
		ResponseEntity<String> responseEntity = callExternalService(message, "https://croamisstg.qatarairways.com.qa/ghaonerec/oRlogisticObject/saveAndPublishLoObject");
		ResponseEntity<String> savedShpResponse = new ResponseEntity<String>(responseEntity.getBody(), HttpStatus.OK);
		return savedShpResponse.getBody();
	}
	
	public LogisticsObjectSO getShipment(SearchShipmentSO searchShipmentSO) {
		
		String jwtToken =  getToken();
		LogisticsObjectSO logisticsObjectSO = new LogisticsObjectSO();
		if(null!=jwtToken) {
			ResponseEntity<String> shpRespEntity = callExternalService("http://localhost:8080/logistics-objects/"+searchShipmentSO.getOneRecordId(), jwtToken);
			ResponseEntity<String> getShpResponse = new ResponseEntity<String>(shpRespEntity.getBody(), HttpStatus.OK);
			
			logisticsObjectSO = new JsonUtil<LogisticsObjectSO>().convertJsonToObject(getShpResponse.getBody(), LogisticsObjectSO.class);
			
		}		
		return logisticsObjectSO;
	}
	
	private String getToken() {
		
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders tokenReqHeader = new HttpHeaders();
		String jwtToken = "";
		tokenReqHeader.setContentType(MediaType.APPLICATION_JSON);
		tokenReqHeader.set("client_id", "neone-client");
		tokenReqHeader.set("client_secret", "lx7ThS5aYggdsMm42BP3wMrVqKm9WpNY");
		tokenReqHeader.set("grant_typ", "client_credentials");
		tokenReqHeader.set("username", "neone-client");
		tokenReqHeader.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		
		HttpEntity<String> headerEntity = new HttpEntity<String>(tokenReqHeader);
		
		ResponseEntity<String> responseEntity = restTemplate.exchange("http://localhost:8989/realms/neone/protocol/openid-connect/token", HttpMethod.GET, headerEntity, String.class);
		ResponseEntity<String> tokenString = new ResponseEntity<String>(responseEntity.getBody(), HttpStatus.OK);
		
		if(null!=tokenString) {
			TokenSO tokenSO = new JsonUtil<TokenSO>().convertJsonToObject(tokenString.getBody(), TokenSO.class);
			jwtToken = tokenSO.getAccess_token();
		}
		return jwtToken;
	}
	
	private ResponseEntity<String> callExternalService(String url, String token) {
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders shpHeader = new HttpHeaders();
		shpHeader.set("Authorization", "Bearer "+token);
		HttpEntity<String> headerEntity = new HttpEntity<String>(shpHeader);;
		ResponseEntity<String> responseEntity = restTemplate.postForEntity(url, headerEntity, String.class);
		
		return responseEntity;
	}
}
