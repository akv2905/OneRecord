package com.onerecordorca.login.schemaobjects;

import java.io.Serializable;

public class Item extends LogisticsObjectSO implements Serializable{

	private static final long serialVersionUID = 1l;

}
