package com.onerecordorca.apihelper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class AwbController {

	@Autowired
	private AwbService awbService;
	
	@RequestMapping(value = "fetchAwbInfo", method = RequestMethod.POST)
	public @ResponseBody AwbResponse fetchAwbInfo(@RequestBody AwbRequest inputData, ModelMap model) {
		System.out.println("inside controller fetchAwbInfo ");
		AwbResponse awb = awbService.getAwbDetails(inputData.getAwbPrfx(), inputData.getAwbNumber());
		awbService.prepareScreeningDom(awb, inputData.getLoginPlace());
		return awb;
	}
	
	@RequestMapping(value = "updateStatus", method = RequestMethod.POST)
	public @ResponseBody AwbResponse  updateStatus(@RequestBody AwbRequest inputData, ModelMap model) {
		System.out.println("inside controller fetchAwbInfo ");
		AwbResponse awb = awbService.updateDetails(inputData.getAwbPrfx(), inputData.getAwbNumber(), inputData.getScreenigUniqueId());
		awbService.prepareScreeningDom(awb, inputData.getLoginPlace());
		return awb;
	}
	
	@RequestMapping(value = "publishToOneRecord", method = RequestMethod.POST)
	public @ResponseBody AwbResponse  publishToOneRecord(@RequestBody AwbRequest inputData, ModelMap model) {
		System.out.println("inside controller fetchAwbInfo ");
		AwbResponse awb = awbService.getAwbDetails(inputData.getAwbPrfx(), inputData.getAwbNumber());
		awb.setOneRecordUpdated(Boolean.TRUE);
		return awb;
	}
	
}
