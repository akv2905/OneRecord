package com.onerecordorca.apihelper;

import java.util.ArrayList;
import java.util.List;

public class AwbResponse {

	public AwbResponse() {
		// TODO Auto-generated constructor stub
	}
	private Long awbId;
	private String awbType;
	private String awbPrfx;
	private String awbNumber;
	
	private String pcs;
	private String weight;
	private String volume;
	private String orig;
	private String dest;
	private String product;
	private String shc;
	private List<AwbFlightDtls> flights;
	private String screeningDom;
	private String loginPlace;
	private Boolean mandateComplted;
	private Boolean oneRecordUpdated;
	public AwbResponse(Long awbId, String awbType, String awbPrfx, String awbNumber, String pcs, String weight, String volume,
			String orig, String dest, String product, String shc) {
		super();
		this.awbId=awbId;
		this.awbType = awbType;
		this.awbPrfx = awbPrfx;
		this.awbNumber = awbNumber;
		this.pcs = pcs;
		this.weight = weight;
		this.volume = volume;
		this.orig = orig;
		this.dest = dest;
		this.product = product;
		this.shc=shc;
	}
	public String getAwbType() {
		return awbType;
	}
	public void setAwbType(String awbType) {
		this.awbType = awbType;
	}
	public String getAwbPrfx() {
		return awbPrfx;
	}
	public void setAwbPrfx(String awbPrfx) {
		this.awbPrfx = awbPrfx;
	}
	public String getAwbNumber() {
		return awbNumber;
	}
	public void setAwbNumber(String awbNumber) {
		this.awbNumber = awbNumber;
	}
	public String getPcs() {
		return pcs;
	}
	public void setPcs(String pcs) {
		this.pcs = pcs;
	}
	public String getWeight() {
		return weight;
	}
	public void setWeight(String weight) {
		this.weight = weight;
	}
	public String getVolume() {
		return volume;
	}
	public void setVolume(String volume) {
		this.volume = volume;
	}
	public String getOrig() {
		return orig;
	}
	public void setOrig(String orig) {
		this.orig = orig;
	}
	public String getDest() {
		return dest;
	}
	public void setDest(String dest) {
		this.dest = dest;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public Long getAwbId() {
		return awbId;
	}
	public void setAwbId(Long awbId) {
		this.awbId = awbId;
	}
	public List<AwbFlightDtls> getFlights() {
		if(flights == null) {
			flights=new ArrayList<AwbFlightDtls>();
		}
		return flights;
	}
	public void setFlights(List<AwbFlightDtls> flights) {
		this.flights = flights;
	}
	public String getScreeningDom() {
		return screeningDom;
	}
	public void setScreeningDom(String screeningDom) {
		this.screeningDom = screeningDom;
	}
	public String getLoginPlace() {
		return loginPlace;
	}
	public void setLoginPlace(String loginPlace) {
		this.loginPlace = loginPlace;
	}
	public Boolean getMandateComplted() {
		return mandateComplted;
	}
	public void setMandateComplted(Boolean mandateComplted) {
		this.mandateComplted = mandateComplted;
	}
	public Boolean getOneRecordUpdated() {
		if(oneRecordUpdated == null) {
			oneRecordUpdated=Boolean.FALSE;
		}
		return oneRecordUpdated;
	}
	public void setOneRecordUpdated(Boolean oneRecordUpdated) {
		this.oneRecordUpdated = oneRecordUpdated;
	}
	public String getShc() {
		return shc;
	}
	public void setShc(String shc) {
		this.shc = shc;
	}
	
	
	
}
