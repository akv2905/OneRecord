package com.onerecordorca.apihelper;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
@Controller
public class SayHelloController {

	@RequestMapping("say-hello")
	@ResponseBody
	public String sayHello() {
		return "Hello! What are you leaning today?";
	}
	
	@RequestMapping("say-hello-html")
	@ResponseBody
	public String sayHelloHtml() {
		StringBuilder sb = new StringBuilder();
		sb.append("<!DOCTYPE html><html><head>     <title> welcome to story book </title></head><body>     <h1>THE SCECRET GARDEN</h1>");
		sb.append("<h2> THERE IS NO ONE LEFT</h2>     <p> When <b> Mary Lenox</b> was sent to <i>misselthwaite Manor ");
		sb.append("</i> to libe with her uncle everybody said she was the most disagreeable looking child ever seen.<p> ");
		sb.append("<ul><li><a href=\"#\"> http//:deepthi.com</a></li> <li><a href=\"#\">https//:deviKrithika.com</a></li> ");
		sb.append("<h1>welcome to DEEPTHI WORLD</h1> <table border=\"0\" cell padding=\"3\" cellspacing=\"7\"> <tr> ");
		sb.append("<td> <button> books</button></td> <td> <button> dress</button></td> <td> <button> pencils</button></td> ");
		sb.append("<td> <button> boxes</button></td> </tr> <tr> <td> <button> 20 </button></td> <td> <button> 30 </button></td> ");
		sb.append("<td> <button> 40 </button></td> <td> <button> 60 </button></td> </tr> <tr> <td> <button>banglore</button></td> ");
		sb.append("<td> <button> dubai</button></td> <td> <button> qatar </button></td> <td> <button> chennai</button></td> ");
		sb.append("</tr> </table> </ul> </body> </html> ");
		return sb.toString();
	}
	
	@RequestMapping("say-hello-jsp")
	public String sayHelloJsp() {
		return "userLogin";
	}
	@GetMapping("/greeting")
	public String greeting(@RequestParam(name="name", required=false, defaultValue="World") String name, Model model) {
		model.addAttribute("name", name);
		return "greeting";
	}
}
