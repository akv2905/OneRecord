package com.onerecordorca.apihelper;

import org.springframework.stereotype.Repository;

@Repository
public class AwbRepositoryHelper {

	public String getAwbOneRecordId(String awbPrfx, String awbNumber) {
		return "f950f9b9-7be6-43b6-9355-3ded1a56ee11";
	}
}
