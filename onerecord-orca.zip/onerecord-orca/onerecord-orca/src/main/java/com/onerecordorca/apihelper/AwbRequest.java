package com.onerecordorca.apihelper;

import java.time.LocalDate;

import jakarta.validation.constraints.Size;

public class AwbRequest {

	private Long id;
	@Size(min = 5, message = "Enter value more than 5 charectors")
	
	private String description;
	private String userName;
	private String userPwd;
	private String loginPlace;
	private LocalDate targetDate;
	private Long screenigUniqueId;
	public AwbRequest() {
		
	}
	
	public AwbRequest(Long id, String description, String userName, LocalDate targetDate, LocalDate createdDate,
			boolean done) {
		super();
		this.id = id;
		this.description = description;
		this.userName = userName;
		this.targetDate = targetDate;
		this.createdDate = createdDate;
		this.done = done;
	}

	private LocalDate createdDate;
	private boolean done;
	
	
	
	private String awbPrfx;
	private String awbNumber;
	
	
	
	
	
	@Override
	public String toString() {
		return "Todo [id=" + id + ", description=" + description + ", userName=" + userName + ", targetDate="
				+ targetDate + ", createdDate=" + createdDate + ", done=" + done + "]";
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public LocalDate getTargetDate() {
		return targetDate;
	}


	public void setTargetDate(LocalDate targetDate) {
		this.targetDate = targetDate;
	}


	public LocalDate getCreatedDate() {
		return createdDate;
	}


	public void setCreatedDate(LocalDate createdDate) {
		this.createdDate = createdDate;
	}


	public boolean isDone() {
		return done;
	}


	public void setDone(boolean done) {
		this.done = done;
	}


	public String getUserPwd() {
		return userPwd;
	}


	public void setUserPwd(String userPwd) {
		this.userPwd = userPwd;
	}


	public String getAwbPrfx() {
		return awbPrfx;
	}


	public void setAwbPrfx(String awbPrfx) {
		this.awbPrfx = awbPrfx;
	}


	public String getAwbNumber() {
		return awbNumber;
	}


	public void setAwbNumber(String awbNumber) {
		this.awbNumber = awbNumber;
	}

	public Long getScreenigUniqueId() {
		return screenigUniqueId;
	}

	public void setScreenigUniqueId(Long screenigUniqueId) {
		this.screenigUniqueId = screenigUniqueId;
	}
	public String getLoginPlace() {
		return loginPlace;
	}
	public void setLoginPlace(String loginPlace) {
		this.loginPlace = loginPlace;
	}
	

}
