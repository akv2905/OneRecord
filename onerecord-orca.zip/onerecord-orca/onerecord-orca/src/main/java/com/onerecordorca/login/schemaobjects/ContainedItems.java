package com.onerecordorca.login.schemaobjects;

import java.io.Serializable;

public class ContainedItems extends Piece implements Serializable{

	private static final long serialVersionUID = 1l;

}
